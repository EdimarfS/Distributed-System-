package main;


public interface DeclareWinnerInterface{
  public String whoWon(char me, char theOther);

}
