import java.util.*;
import java.io.*;
import java.net.*;

class Client
{
    public static void main(String[] args)
        throws Exception
    {
        int port = 12345;
        String computer = "localhost";
		


        Person p = new Person("amy", "will");
        Person p2 = new Person("anna", "soc");

        try {
            Socket s = new Socket(computer, port);
			


            ObjectOutputStream oos
              = new ObjectOutputStream(s.getOutputStream());

            ObjectInputStream inputObject
              = new ObjectInputStream(s.getInputStream());
            oos.writeObject(p);
            oos.writeObject(p2);
            oos.flush();
            
			p = (Person) inputObject.readObject();
            System.out.println(p.getFamilyName());
			
            p2 = (Person) inputObject.readObject();
            System.out.println(p2.getFamilyName());
            



        }catch(Exception e){

        }

    }
}