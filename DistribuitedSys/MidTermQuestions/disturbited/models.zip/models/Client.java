

import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class Client{
   private static Scanner in;
    private static PrintWriter out;

    public static void main(String [] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Please give me server address and port, for example 127.0.0.1:5601");
        String [] serverAndPort  = sc.nextLine().split(":");
        sc.close();

       try(Socket socket = new Socket(serverAndPort[0], Integer.parseInt(serverAndPort[1]))) {
           in = new Scanner(socket.getInputStream());
           out = new PrintWriter(socket.getOutputStream(), true);

           System.out.println("Use numbers 0 - 8 to make a move, Board cells numbered 0-8, top to bottom, left to right");
           Scanner scanner = new Scanner(System.in);

           String response = in.nextLine();
           if(response.charAt(response.length() - 1) == '1') {
               System.out.println("You are player 1");
               response = in.nextLine();
               System.out.println(response);
           } else {
               System.out.println("You are player 2");
               response = in.nextLine();
               if(response.equals("Make your move")) {
                   move(scanner);
               }
           }

           while (true) {
               response = in.nextLine();

               if (response.startsWith("valid move")) {
                   System.out.println("Valid move, please wait");
               } else if (response.startsWith("opponent has moved")) {
                   System.out.println(response);
                   move(scanner);
               } else if (response.startsWith("message")) {
                   System.out.println(response.substring(8));
               } else if (response.startsWith("won")) {
                   System.out.println("You have won");
                   break;
               } else if (response.startsWith("lost")) {
                   System.out.println("You have lost");
                   break;
               } else if (response.startsWith("draw")) {
                   System.out.println("Draw");
                   break;
               } else if (response.startsWith("player left")) {
                   System.out.println("Other player left the game");
                   break;
               }
           }
           out.println("quit");
       } catch (Exception ex) {
           System.out.println(ex);
       }
    }

    private static void move(Scanner scanner) {
        int position = scanner.nextInt();
        out.println("move " + position);
    }
}
